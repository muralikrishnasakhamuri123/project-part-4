-- Created by Vertabelo (http://vertabelo.com)
-- Last modification date: 2022-04-13 08:38:02.516

-- tables
-- Table: Resturant_details
CREATE TABLE Resturant_details (
    r_id varchar(100)  NOT NULL,
    r_name varchar(100)  NOT NULL,
    location varchar(100)  NOT NULL,
    stock_id int  NOT NULL,
    CONSTRAINT Resturant_details_pk PRIMARY KEY  (r_id)
);

-- Table: food_item
CREATE TABLE food_item (
    food_name varchar(100)  NOT NULL,
    qty int  NOT NULL,
    price int  NOT NULL,
    CONSTRAINT food_item_pk PRIMARY KEY  (food_name)
);

-- Table: special_item
CREATE TABLE special_item (
    item_id varchar(100)  NOT NULL,
    qty int  NOT NULL,
    price int  NOT NULL,
    item_details varchar(100)  NOT NULL,
    food_name varchar(100)  NOT NULL,
    CONSTRAINT special_item_pk PRIMARY KEY  (item_id)
);

-- Table: stock_item
CREATE TABLE stock_item (
    stock_id int  NOT NULL,
    total_food int  NOT NULL,
    total_special_item int  NOT NULL,
    available_food int  NOT NULL,
    available_special_item int  NOT NULL,
    CONSTRAINT stock_item_pk PRIMARY KEY  (stock_id)
);

-- foreign keys
-- Reference: Resturant_details_stock_item (table: Resturant_details)
ALTER TABLE Resturant_details ADD CONSTRAINT Resturant_details_stock_item
    FOREIGN KEY (stock_id)
    REFERENCES stock_item (stock_id);

-- Reference: special_item_food_item (table: special_item)
ALTER TABLE special_item ADD CONSTRAINT special_item_food_item
    FOREIGN KEY (food_name)
    REFERENCES food_item (food_name);

-- End of file.

