-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.3.13-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for resturant
CREATE DATABASE IF NOT EXISTS `resturant` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `resturant`;

-- Dumping structure for table resturant.food_item
CREATE TABLE IF NOT EXISTS `food_item` (
  `food_name` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`food_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table resturant.food_item: ~3 rows (approximately)
/*!40000 ALTER TABLE `food_item` DISABLE KEYS */;
INSERT INTO `food_item` (`food_name`, `qty`, `price`) VALUES
	('bergger', 1, 200),
	('chicken pizza', 1, 1000),
	('pattis', 1, 500),
	('piza', 2, 1000);
/*!40000 ALTER TABLE `food_item` ENABLE KEYS */;

-- Dumping structure for table resturant.resturant_details
CREATE TABLE IF NOT EXISTS `resturant_details` (
  `r_id` varchar(100) NOT NULL,
  `r_name` varchar(100) NOT NULL,
  `location` varchar(100) NOT NULL,
  `stock_id` int(11) NOT NULL,
  PRIMARY KEY (`r_id`),
  KEY `Resturant_details_stock_item` (`stock_id`),
  CONSTRAINT `Resturant_details_stock_item` FOREIGN KEY (`stock_id`) REFERENCES `stock_item` (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table resturant.resturant_details: ~0 rows (approximately)
/*!40000 ALTER TABLE `resturant_details` DISABLE KEYS */;
INSERT INTO `resturant_details` (`r_id`, `r_name`, `location`, `stock_id`) VALUES
	('r1', 'pizza hut', 'london', 1),
	('r2', 'evening cafe', 'london', 2),
	('r3', 'helthy resturant', 'london', 3);
/*!40000 ALTER TABLE `resturant_details` ENABLE KEYS */;

-- Dumping structure for table resturant.special_item
CREATE TABLE IF NOT EXISTS `special_item` (
  `item_id` varchar(100) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  `item_details` varchar(100) NOT NULL,
  `food_name` varchar(100) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `special_item_food_item` (`food_name`),
  CONSTRAINT `special_item_food_item` FOREIGN KEY (`food_name`) REFERENCES `food_item` (`food_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table resturant.special_item: ~0 rows (approximately)
/*!40000 ALTER TABLE `special_item` DISABLE KEYS */;
INSERT INTO `special_item` (`item_id`, `qty`, `price`, `item_details`, `food_name`) VALUES
	('i1', 1, 200, 'delicious', 'piza'),
	('i2', 1, 300, 'testy', 'bergger'),
	('i3', 1, 400, 'helthy', 'pattis');
/*!40000 ALTER TABLE `special_item` ENABLE KEYS */;

-- Dumping structure for table resturant.stock_item
CREATE TABLE IF NOT EXISTS `stock_item` (
  `stock_id` int(11) NOT NULL,
  `total_food` int(11) NOT NULL,
  `total_special_item` int(11) NOT NULL,
  `available_food` int(11) NOT NULL,
  `available_special_item` int(11) NOT NULL,
  PRIMARY KEY (`stock_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table resturant.stock_item: ~0 rows (approximately)
/*!40000 ALTER TABLE `stock_item` DISABLE KEYS */;
INSERT INTO `stock_item` (`stock_id`, `total_food`, `total_special_item`, `available_food`, `available_special_item`) VALUES
	(1, 100, 50, 50, 25),
	(2, 200, 50, 100, 25),
	(3, 50, 50, 50, 25);
/*!40000 ALTER TABLE `stock_item` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
